package parser;

import scanner.ScanErrorException;
import scanner.Scanner;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

public class Parser
{

    private Scanner scanner;
    private String currentToken;
    private HashMap<String, Integer> variables;

    public static void main(String[] args) throws ScanErrorException, FileNotFoundException
    {
        run("C:\\Users\\analyst\\IdeaProjects\\scanner2\\src\\main\\java\\parser\\parserTest0.txt");
    }


    public Parser(Scanner s) throws ScanErrorException
    {
        this.scanner = s;
        currentToken = scanner.nextToken();
        variables = new HashMap<>();
    }

    private String eat(String expected) throws ScanErrorException
    {
        String a = currentToken;
        if (currentToken.equals(expected))
        {
            currentToken = scanner.nextToken();
            return currentToken;
        }
        else
            throw new IllegalArgumentException("Expected " + expected + " but found " + currentToken + ".");
    }

    public static void run(String path) throws FileNotFoundException, ScanErrorException
    {
        new Parser(new Scanner(new FileInputStream(path))).run();
    }

    public void run() throws ScanErrorException
    {
        while (scanner.hasNext())
        {
            parseStatement();
        }
    }

    private void allTokens() throws ScanErrorException
    {
        while (scanner.hasNext())
            System.out.println(scanner.nextToken());
    }

    /**
     * Takes in a number and returns it as an int.
     * precondition: current token is an integer
     * postcondition: number token has been eaten
     *
     * @return the value of the parsed integer
     */
    private int parseNumber(String a) throws ScanErrorException
    {
        int toReturn = Integer.parseInt(a);
        eat(a);
        return toReturn;
    }

    /**
     *
     */
    private void parseStatement() throws ScanErrorException
    {
        if (currentToken.compareTo("WRITELN") == 0)
        {
            eat("WRITELN");
            System.out.println(parseTerm());
            eat(";");
        }
        else if (currentToken.compareTo("BEGIN") == 0)
            eat(currentToken);
        else if (currentToken.compareTo("END") == 0)
        {
            eat("END");
            eat(";");
        }
        else if (currentToken.compareTo(".") == 0)
        {
        }
        else
        {
            parseAssignment();
        }
    }

    /**
     * @return
     */
    private int parseAssignment() throws ScanErrorException
    {
        String variable = currentToken;
        StringBuilder newVal = new StringBuilder();
        int newEvaluatedValue = 0;
        eat(currentToken);
        eat(":= ");
        while (currentToken.compareTo(";") != 0)
        {
            newVal.append(currentToken);
            eat(currentToken);
        }
        newEvaluatedValue = parseTerm(newVal.toString());
        variables.put(variable, newEvaluatedValue);
        while (currentToken.compareTo(";") == 0)
            eat(currentToken);
        return newEvaluatedValue;
    }


    private int parseTerm() throws ScanErrorException
    {
        String toParse = "";
        int paren = 1;
        toParse += currentToken;
        eat(currentToken);
        while (paren != 0)
        {
            if (currentToken.contains("("))
            {
                paren += currentToken.split("\\(", -1).length - 1;
            }
            else if (currentToken.contains(")"))
            {
                paren -= currentToken.split("\\)", -1).length - 1;
            }
            toParse += currentToken;
            eat(currentToken);
        }
        return parseTerm(toParse);
    }

    /**
     * Calculates expressions with any of the following operators: + - / * %
     * In addition, variables will be replaced with their proper replacement.
     *
     * @param a the term to parse
     * @return the evaluated expression
     * @throws ScanErrorException if the scanner mismatches with what was expected
     */
    @SuppressWarnings("StatementWithEmptyBody")
    private int parseTerm(String a) throws ScanErrorException
    {
        for (Map.Entry<String, Integer> entry : variables.entrySet())
            a = a.replace(entry.getKey(), entry.getValue().toString());

        a = a.replace(" ", "");
        if (isInteger(a))
            return Integer.parseInt(a);
        while (a.indexOf('(') != -1)
        {
            String b = a.substring(0, a.indexOf(")"));
            String c = b.substring(b.lastIndexOf("(") + 1);
            a = a.replace("(" + c + ")", String.valueOf(parseTerm(c)));
            a = a.replace("--", ""); // resolves "-(-1)"
        }
        while (a.indexOf('*') != -1 || a.indexOf('/') != -1)
        {

            if ((a.indexOf('*') < a.indexOf('/') && (a.contains("*"))) || !a.contains("/"))
            {
                if (a.indexOf('*') != -1)
                {
                    int startOfExpr;
                    int endOfExpr;
                    for (startOfExpr = a.indexOf('*') - 1; startOfExpr >= 0 && isInteger(a.substring(startOfExpr, startOfExpr + 1)); startOfExpr--)
                    {
                        //empty
                    }
                    for (endOfExpr = a.indexOf('*') + 1; endOfExpr < a.length() && isInteger(a.substring(endOfExpr, endOfExpr + 1)); endOfExpr++)
                    {
                        //empty
                    }
                    String toCalculate = a.substring(startOfExpr + 1, endOfExpr);
                    a = a.replace(toCalculate, String.valueOf(parseTerm(toCalculate.substring(0
                            , toCalculate.indexOf("*"))) * parseTerm(toCalculate.substring(toCalculate.indexOf("*") + 1))));
                }
            }
            else if (a.indexOf('/') != -1)
            {
                int startOfExpr;
                int endOfExpr;
                for (startOfExpr = a.indexOf('/') - 1; startOfExpr >= 0 && isInteger(a.substring(startOfExpr, startOfExpr + 1)); startOfExpr--)
                {
                    //empty
                }
                for (endOfExpr = a.indexOf('/') + 1; endOfExpr < a.length() && isInteger(a.substring(endOfExpr, endOfExpr + 1)); endOfExpr++)
                {
                    //empty
                }
                String toCalculate = a.substring(startOfExpr + 1, endOfExpr);
                a = a.replace(toCalculate, String.valueOf(parseTerm(toCalculate.substring(0
                        , toCalculate.indexOf("/"))) / parseTerm(toCalculate.substring(toCalculate.indexOf("/") + 1))));
            }
        }
        while (a.indexOf('+') != -1 || a.indexOf('-') != -1)
        {
            if ((a.indexOf('+') < a.indexOf('-') && a.contains("+")) || !a.contains("-"))
            {
                if (a.indexOf('+') != -1)
                {
                    int startOfExpr;
                    int endOfExpr;
                    for (startOfExpr = a.indexOf('+') - 1; startOfExpr >= 0 && isInteger(a.substring(startOfExpr, startOfExpr + 1)); startOfExpr--)
                    {
                        //empty
                    }
                    for (endOfExpr = a.indexOf('+') + 1; endOfExpr < a.length() && isInteger(a.substring(endOfExpr, endOfExpr + 1)); endOfExpr++)
                    {
                        //empty
                    }
                    String toCalculate = a.substring(startOfExpr + 1, endOfExpr);
                    a = a.replace(toCalculate, String.valueOf(parseTerm(toCalculate.substring(0
                            , toCalculate.indexOf("+"))) + parseTerm(toCalculate.substring(toCalculate.indexOf("+") + 1))));
                }
            }
            else if (a.indexOf('-') != -1)
            {
                int startOfExpr;
                int endOfExpr;
                for (startOfExpr = a.indexOf('-') - 1; startOfExpr >= 0 && isInteger(a.substring(startOfExpr, startOfExpr + 1)); startOfExpr--)
                {
                    //empty
                }
                for (endOfExpr = a.indexOf('-') + 1; endOfExpr < a.length() && isInteger(a.substring(endOfExpr, endOfExpr + 1)); endOfExpr++)
                {
                    //empty
                }
                String toCalculate = a.substring(startOfExpr + 1, endOfExpr);
                a = a.replace(toCalculate, String.valueOf(parseTerm(toCalculate.substring(0
                        , toCalculate.indexOf("-"))) - parseTerm(toCalculate.substring(toCalculate.indexOf("-") + 1))));
            }
        }
        while (a.indexOf('%') != -1)
        {
            int startOfExpr;
            int endOfExpr;
            for (startOfExpr = a.indexOf('%') - 1; startOfExpr >= 0 && isInteger(a.substring(startOfExpr, startOfExpr + 1)); startOfExpr--)
            {
                //empty
            }
            for (endOfExpr = a.indexOf('%') + 1; endOfExpr < a.length() && isInteger(a.substring(endOfExpr, endOfExpr + 1)); endOfExpr++)
            {
                //empty
            }
            String toCalculate = a.substring(startOfExpr + 1, endOfExpr);
            a = a.replace(toCalculate, String.valueOf(parseTerm(toCalculate.substring(0
                    , toCalculate.indexOf("%"))) % parseTerm(toCalculate.substring(toCalculate.indexOf("%") + 1))));
        }
        return Integer.parseInt(a);
    }

    private static boolean isInteger(String a)
    {
        try
        {
            Integer.parseInt(a);
        }
        catch (NumberFormatException e)
        {
            return false;
        }
        return true;
    }
}